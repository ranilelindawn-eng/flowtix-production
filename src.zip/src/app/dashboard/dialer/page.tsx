import { requirePermission } from '@/lib/auth'

import DialerClient from './DialerClient'
import { getDialerContactById } from './actions'

type DialerPageProps = {
  searchParams?: Promise<{
    contactId?: string
    phone?: string
  }>
}

export default async function DialerPage({
  searchParams,
}: DialerPageProps) {
  const params = await searchParams

  await requirePermission('calls.create')

  const contactId = params?.contactId?.trim() ?? ''
  const initialPhoneNumber = params?.phone?.trim() ?? ''

  const initialContact =
    contactId.length > 0
      ? await getDialerContactById(contactId)
      : null

  return (
    <DialerClient
      initialContact={initialContact}
      initialPhoneNumber={initialPhoneNumber}
    />
  )
}