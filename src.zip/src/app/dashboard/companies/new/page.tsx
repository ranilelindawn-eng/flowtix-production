import Link from 'next/link'

import OwnerSelect from '@/components/ownership/OwnerSelect'
import { getAssignableMembers } from '@/lib/ownership'
import { getCurrentOrganization } from '@/lib/team'

import { createCompany } from '../../crm-actions'

const input = 'min-h-11 w-full rounded-xl border border-white/10 bg-[#07111F] px-3 text-sm text-white outline-none focus:border-blue-500'

export default async function NewCompanyPage() {
  const membership = await getCurrentOrganization()
  if (!membership) throw new Error('Unable to determine the current organization.')
  const owners = await getAssignableMembers(membership)

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <Link href="/dashboard/companies" className="text-sm text-cyan-400">← Companies</Link>
        <h1 className="mt-3 text-3xl font-semibold text-white">Add company</h1>
      </div>
      <form action={createCompany} className="grid gap-5 rounded-2xl border border-white/10 bg-[#0B1726]/90 p-6 md:grid-cols-2">
        <label className="md:col-span-2 text-sm text-slate-300">Company name<input required name="name" className={`${input} mt-2`}/></label>
        <OwnerSelect members={owners} className={input} />
        <label className="text-sm text-slate-300">Status<select name="status" className={`${input} mt-2`}><option value="prospect">Prospect</option><option value="active">Active</option><option value="customer">Customer</option><option value="inactive">Inactive</option></select></label>
        <label className="text-sm text-slate-300">Domain<input name="domain" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">Industry<input name="industry" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">Email<input type="email" name="email" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">Phone<input name="phone" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">Website<input name="website" className={`${input} mt-2`}/></label>
        <label className="md:col-span-2 text-sm text-slate-300">Address<input name="address" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">City<input name="city" className={`${input} mt-2`}/></label>
        <label className="text-sm text-slate-300">Country<input name="country" className={`${input} mt-2`}/></label>
        <label className="md:col-span-2 text-sm text-slate-300">Description<textarea name="description" rows={5} className={`${input} mt-2 py-3`}/></label>
        <button className="md:col-span-2 min-h-11 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-500">Create company</button>
      </form>
    </div>
  )
}
