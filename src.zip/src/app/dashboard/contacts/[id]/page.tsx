import { notFound } from 'next/navigation'

import ContactAISummary from '@/components/contacts/ContactAISummary'
import ContactHeader from '@/components/contacts/ContactHeader'
import ContactProfileCard from '@/components/contacts/ContactProfileCard'
import ContactQuickActions from '@/components/contacts/ContactQuickActions'
import ContactTimeline from '@/components/contacts/ContactTimeline'
import { requirePermission } from '@/lib/auth'
import { getContactActivity } from '@/lib/contact-activity'
import { getContactCalls } from '@/lib/contact-calls'
import { getContactNotes } from '@/lib/contact-notes'
import { getContactTasks } from '@/lib/contact-tasks'
import { getContact } from '@/lib/contacts'

type ContactPageProps = {
  params: Promise<{
    id: string
  }>
}

export default async function ContactPage({
  params,
}: ContactPageProps) {
  await requirePermission('contacts.view')

  const { id } = await params

  const [contact, calls, notes, tasks] = await Promise.all([
    getContact(id),
    getContactCalls(id),
    getContactNotes(id),
    getContactTasks(id),
  ])

  if (!contact) {
    notFound()
  }

  const activities = getContactActivity({
    calls,
    notes,
    tasks,
  })

  return (
    <div className="space-y-6">
      <ContactHeader contact={contact} />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,0.72fr)_minmax(0,1.28fr)_minmax(280px,0.62fr)]">
        <div className="min-w-0">
          <ContactProfileCard contact={contact} />
        </div>

        <div className="min-w-0 space-y-6">
          <ContactAISummary contact={contact} />

          <ContactTimeline
            contactId={contact.id}
            activities={activities}
          />
        </div>

        <aside className="min-w-0">
          <ContactQuickActions contact={contact} />
        </aside>
      </div>
    </div>
  )
}