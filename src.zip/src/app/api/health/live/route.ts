import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic'
export async function GET() {
  return NextResponse.json({ status: 'ok', service: 'flowtix-web', timestamp: new Date().toISOString() }, { headers: { 'Cache-Control': 'no-store' } })
}
