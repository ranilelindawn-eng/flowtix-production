import { NextResponse } from "next/server";
import { processJobs } from "@/lib/jobs/worker";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(request: Request) {
  try {
    const expected =
      process.env.INTERNAL_JOB_WORKER_SECRET?.trim();

    const authorization =
      request.headers.get("authorization");

    const supplied =
      authorization?.startsWith("Bearer ")
        ? authorization.slice(7).trim()
        : "";

    console.log("CRON AUTH DEBUG", {
      expectedExists: Boolean(expected),
      expectedLength: expected?.length,
      suppliedLength: supplied.length,
      expectedStart: expected?.slice(0, 5),
      suppliedStart: supplied.slice(0, 5),
      expectedEnd: expected?.slice(-5),
      suppliedEnd: supplied.slice(-5),
      matches: supplied === expected,
    });

    if (!expected) {
      return NextResponse.json(
        {
          ok: false,
          error: "Missing INTERNAL_JOB_WORKER_SECRET",
        },
        {
          status: 500,
        },
      );
    }

    if (supplied !== expected) {
      return NextResponse.json(
        {
          ok: false,
          error: "Unauthorized worker request",
        },
        {
          status: 401,
        },
      );
    }

    const result = await processJobs({
      workerId: "vercel-cron",
      queues: [
        "communications",
        "default",
        "post_call",
        "sequences",
        "campaigns",
        "telephony",
        "ai",
      ],
      limit: 25,
      leaseSeconds: 300,
    });

    return NextResponse.json({
      ok: true,
      workerId: "vercel-cron",
      processedAt: new Date().toISOString(),
      ...result,
    });
  } catch (error) {
    console.error(
      "Cron background worker failed.",
      error,
    );

    return NextResponse.json(
      {
        ok: false,
        error:
          error instanceof Error
            ? error.message
            : "Unknown error",
      },
      {
        status: 500,
      },
    );
  }
}