import { NextResponse } from "next/server";

import { createAdminClient } from "@/lib/supabase/admin";


export async function POST(request: Request) {

  try {

    const body = await request.json();


    console.log(
      "PAYMONGO WEBHOOK RECEIVED:",
      JSON.stringify(body, null, 2)
    );


    const event = body?.data;


    const eventType =
      event?.attributes?.type;



    if (
      eventType !== "checkout_session.payment.paid"
    ) {

      console.log(
        "IGNORED EVENT:",
        eventType
      );


      return NextResponse.json({
        received: true
      });

    }



    const checkoutSession =
      event?.attributes?.data;



    if (!checkoutSession) {

      return NextResponse.json(
        {
          error: "Missing checkout session data"
        },
        {
          status: 400
        }
      );

    }



    const checkoutId =
      checkoutSession.id;



    const attributes =
      checkoutSession.attributes;



    const metadata =
      attributes?.metadata;



    const organizationId =
      metadata?.organization_id;



    const planCode =
      metadata?.plan_code;



    if (
      !organizationId ||
      !planCode
    ) {

      console.error(
        "Missing PayMongo metadata:",
        metadata
      );


      return NextResponse.json(
        {
          error: "Missing metadata"
        },
        {
          status: 400
        }
      );

    }



    const supabase =
      createAdminClient();



    /*
      Find selected plan
    */

    const {
      data: plan,
      error: planError
    } =
      await supabase
      .from("subscription_plans")
      .select("id, code, name")
      .eq(
        "code",
        planCode
      )
      .single();



    if (
      planError ||
      !plan
    ) {

      console.error(
        "PLAN LOOKUP ERROR:",
        planError
      );


      return NextResponse.json(
        {
          error: "Plan not found"
        },
        {
          status:404
        }
      );

    }



    /*
      Get PayMongo payment ID
    */

    const paymentId =
      attributes
      ?.payments?.[0]?.id ?? null;



    /*
      Update subscription
    */

    const {
      error: updateError
    } =
      await supabase
      .from(
        "organization_subscriptions"
      )
      .update({

        plan_id:
          plan.id,

        status:
          "active",

        paymongo_checkout_id:
          checkoutId,

        paymongo_plan_code:
          planCode,

        paymongo_payment_id:
          paymentId

      })
      .eq(
        "organization_id",
        organizationId
      );



    if(updateError){

      console.error(
        "DATABASE UPDATE ERROR:",
        updateError
      );


      return NextResponse.json(
        {
          error:updateError.message
        },
        {
          status:500
        }
      );

    }



    console.log(
      "SUBSCRIPTION UPDATED SUCCESSFULLY",
      {
        organizationId,
        planCode
      }
    );



    return NextResponse.json({

      success:true

    });



  } catch(error) {


    console.error(
      "WEBHOOK ERROR:",
      error
    );


    return NextResponse.json(
      {
        error:"Webhook failed"
      },
      {
        status:500
      }
    );

  }

}