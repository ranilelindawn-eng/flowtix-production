import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";
import { getCurrentOrganization } from "@/lib/team";


const PLANS = {
  Starter: {
    code: "starter",
    amount: 170000,
    name: "CallFlow Starter",
  },

  Professional: {
    code: "pro",
    amount: 460000,
    name: "CallFlow Professional",
  },

  Business: {
    code: "business",
    amount: 1150000,
    name: "CallFlow Business",
  },

  Enterprise: {
    code: "enterprise",
    amount: 2900000,
    name: "CallFlow Enterprise",
  },
};



export async function POST(request: Request) {

  try {

    const secretKey =
      process.env.PAYMONGO_SECRET_KEY;


    if (!secretKey) {

      return NextResponse.json(
        {
          error:"Missing PAYMONGO_SECRET_KEY"
        },
        {
          status:500
        }
      );

    }


    const organization =
      await getCurrentOrganization();


    if (!organization) {

      return NextResponse.json(
        {
          error:"Organization not found"
        },
        {
          status:401
        }
      );

    }



    const formData =
      await request.formData();


    const selectedPlan =
      formData.get("plan")?.toString();



    if (
      !selectedPlan ||
      !PLANS[selectedPlan as keyof typeof PLANS]
    ){

      return NextResponse.json(
        {
          error:"Invalid plan"
        },
        {
          status:400
        }
      );

    }



    const plan =
      PLANS[
        selectedPlan as keyof typeof PLANS
      ];



    const response =
      await fetch(
        "https://api.paymongo.com/v1/checkout_sessions",
        {

          method:"POST",

          headers:{
            "Content-Type":"application/json",

            Authorization:
              "Basic " +
              Buffer
              .from(`${secretKey}:`)
              .toString("base64")
          },


          body:JSON.stringify({

            data:{
  attributes:{

    line_items:[

      {
        currency:"PHP",

        amount:
          plan.amount,

        name:
          plan.name,

        quantity:1
      }

    ],


    payment_method_types:[

      "card",
      "gcash",
      "paymaya"

    ],


    metadata:{

      organization_id:
        organization.organization_id,

      plan_code:
        plan.code

    },


    success_url:
    `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?checkout=success`,


    cancel_url:
    `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?checkout=cancelled`

  }
}

          })

        }
      );



    const data =
      await response.json();



    if(!response.ok){

      console.error(
        "PAYMONGO ERROR",
        data
      );


      return NextResponse.json(
        {
          error:"PayMongo failed",
          details:data
        },
        {
          status:response.status
        }
      );

    }



    const checkoutId =
      data.data.id;



    const supabase =
      await createClient();



    const {
      error:updateError
    } = await supabase
    .from("organization_subscriptions")
    .update({

      paymongo_checkout_id:
        checkoutId,

      paymongo_plan_code:
        plan.code,

      status:
        "pending"

    })
    .eq(
      "organization_id",
      organization.organization_id
    );



    if(updateError){

      console.error(
        "SUBSCRIPTION UPDATE ERROR",
        updateError
      );

    }



    return NextResponse.redirect(
      data.data.attributes.checkout_url
    );


  }

  catch(error){

    console.error(
      "PAYMONGO ERROR",
      error
    );


    return NextResponse.json(
      {
        error:"Server error"
      },
      {
        status:500
      }
    );

  }

}